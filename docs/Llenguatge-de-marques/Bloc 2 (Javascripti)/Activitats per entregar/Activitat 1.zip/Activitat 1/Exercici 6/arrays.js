let frase = prompt("Introdueix una cadena de text")
let totalParaules = frase.split(" ") 
let arrData = []

for (let i = 0; i<totalParaules.length; i++){
    arrData.push(totalParaules[i])
}

console.log(arrData)


document.write(`La array té ${arrData.length} paraules <br>`)
document.write(`La primera paraula es ${arrData[0]} y la darrera paraula es ${arrData[arrData.length -1]} <br>`)

arrData.reverse()
let novaString = ``
for (let i = 0; i < arrData.length; i++) {
    novaString += `${arrData[i]} `
}
document.write(novaString)

