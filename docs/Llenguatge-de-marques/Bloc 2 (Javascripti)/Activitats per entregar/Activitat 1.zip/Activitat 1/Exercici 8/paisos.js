 function myFunction() {
    return utils.add()
}

let utils = {
    arrData: [],
    getElements: function (){
        return{
            pais: document.getElementById("pais").value,
            continent: document.getElementById("continent").value,
            llengua: document.getElementById("llengua").value,
            moneda: document.getElementById("moneda").value
        }
    },
    add: function (){
       this.arrData.push(this.getElements())
       console.log(this.arrData)
       this.printElements()
    },

    printElements: function() {
        content = ``
        for (let i = 0; i < this.arrData.length; i++) {
            content += `
            <ul>
            <li>${this.arrData[i].pais}</li>
            <ul>
            <li>${this.arrData[i].continent}</li>
            <li>${this.arrData[i].llengua}</li>
            <li>${this.arrData[i].moneda}</li>
            </ul>
            </ul>
            `
        }
        document.getElementById("salida").innerHTML = content
    }

    }
