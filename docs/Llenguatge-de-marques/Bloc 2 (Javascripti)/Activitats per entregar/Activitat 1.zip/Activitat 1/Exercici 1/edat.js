let edad = parseInt(prompt("Quina es la teva edad?"))

if (edad =>18) {
    document.write("Accés permès")
} else {
    document.write("Accés denegat")
}