function myFunction(){
    
    let n1 = document.getElementById("1")
    let n2 = document.getElementById("2")
    let n3 = document.getElementById("3")
    let n4 = document.getElementById("4")
    let n5 = document.getElementById("5")
    let n6 = document.getElementById("6")
    let n7 = document.getElementById("7")
    let n8 = document.getElementById("8")
    let n9 = document.getElementById("9")
    let n10 = document.getElementById("10")

    let first = document.getElementById("first")
    let second = document.getElementById("second")
    let operator = document.getElementById("operator")

    
}

